int main() {
	function1();
	function2();
}
